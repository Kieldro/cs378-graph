Course Name: CS378
Unique: 91060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 25
Actual    number of hours: 25 (8+17)

Turnin CS Username: keo
GitHub ID: Kieldro
GitHub Repository Name: cs378-graph

Comments:
partially complete

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.